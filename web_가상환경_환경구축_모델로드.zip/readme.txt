# 개발단계 준비
    - 패키지 설치 정보 추출(개발했던 환경에서)
        - $ pip freeze > requirements.txt
    - 모델 덤프

# 구동 환경 구축
    - 프로젝트 폴더 생성
    - 패키지 명시 파일 복사 배치
        - requirements.txt
        - web 이하 웹 프로젝트 배치
    - 가상 환경 구축
        - $ python -m venv dl 
    - 가상 환경 활성화    
        - $ . ./dl/Scripts/activate    
    - 패키지 설치 (한번에 모두 설치)
        - $ pip install -r requirements.txt
    - 필요에 따라 cuda 설치
        - 모델에 cuda가 관여된 모델들은 cuda 처리 필요
    
# 파일 배치
    L dl                                                : 가상환경
    L web                                               : 웹
        L models
            L HourGlass
                L F_Landmarks2_6pts - 최종_f.hdf5       : 사전에 학습한 모델 파일
        L templates
            L upload.html                               : 업로드 사이트
        L run.py                                        : 서버 가동 코드
    L requirements.txt                                  : 개발시 사용한 패키지 목록 

# 서버 가동
    - $ cd web
    - $ python ./web/run.py