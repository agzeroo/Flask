from flask import Flask, render_template, request

######################################################
# 기존 개발시 사용한 패키지 목록
import cv2
from PIL import Image, ImageDraw
from tensorflow.keras.models import load_model
import numpy as np
from tensorflow.keras.preprocessing.image import img_to_array
from matplotlib import pyplot as plt
import cvlib as cv
from scipy.spatial import distance as dist
import timeit
######################################################
import os
print( os.getcwd() )
app = Flask(__name__)

@app.route('/upload', methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return render_template("upload.html")
    else:
        f   = request.files.get('file')
        ##########################
        # 모델 로드
        # 구동 위치에 따라 경로를 달라질수 있음
        model_path = os.getcwd() + '/models/HourGlass/F_Landmarks2_6pts - 최종_f.hdf5'
        print( model_path )
        best_model = load_model( model_path )
        ##########################
        # 이미지 전처리
        # 로드된 모델에 넣어서 예측 수행
        ##########################
        path = f'./static/{f.filename}'
        f.save( path )
        res = {
            "code":0,
            "msg":"당신의 관상은 50대 이후에 돈을 엄청 벌 관상입니다. ..."
        }
        return render_template( "result.html", path=path[1:], predict=res )

if __name__ == '__main__':
    app.run(debug=True)
    pass